# MinTIC2022

Collección de notebooks para complementar el curso a realizar.

La estructura apoya el curso con la siguiente estructura:

## Semana 1

* Sesión 1	[Herramientas de desarrollo en la Web y Programación en Python](https://github.com/arleserp/MinTIC2022/blob/master/1-Tareas%20B%C3%A1sicas%20en%20Python.ipynb)
* Sesión 2	Herramientas de desarrollo
* Sesión 3	Programación, Lenguajes, Algoritmo
* Sesión 4	Programación, Lenguajes, Algoritmo
* Sesión 5	[Operaciones aritméticas y lógicas](https://github.com/arleserp/MinTIC2022/blob/master/5-6.%20Utilizando%20Python%20como%20una%20calculadora.ipynb)
* Sesión 6	[Operaciones aritméticas y lógicas e Intro a Funciones](https://github.com/arleserp/MinTIC2022/blob/master/5-6.%20Utilizando%20Python%20como%20una%20calculadora.ipynb)
